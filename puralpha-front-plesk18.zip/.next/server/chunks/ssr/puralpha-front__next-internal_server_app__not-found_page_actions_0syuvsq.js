module.exports=[15914,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app__not-found_page_actions_0syuvsq.js.map