1:"$Sreact.fragment"
2:I[51725,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],""]
3:I[57656,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"flex flex-col items-center justify-center min-h-screen","children":[["$","h2",null,{"className":"text-3xl font-bold","children":"Non trouvé"}],["$","p",null,{"className":"mt-4","children":"Impossible de trouver la ressource demandée"}],["$","$L2",null,{"href":"/","className":"mt-6 text-blue-500 hover:underline","children":"Retour à l'accueil"}]]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"iSXSXLPEAgYvViEcjDVtR"}
5:null
