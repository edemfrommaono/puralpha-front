1:"$Sreact.fragment"
2:I[37951,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"Header"]
3:I[92959,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"default"]
4:I[28614,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"default"]
5:I[51725,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],""]
6:I[93962,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"Footer"]
7:I[59659,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"CookieConsent"]
8:I[68257,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"ClientPageRoot"]
9:I[85004,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js","/_next/static/chunks/0i-3q5ub1e~p0.js","/_next/static/chunks/16swoytb4~dmc.js"],"default"]
c:I[57656,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"OutletBoundary"]
d:"$Sreact.suspense"
10:I[57656,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"ViewportBoundary"]
12:I[57656,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"MetadataBoundary"]
14:I[67303,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"default",1]
:HL["/_next/static/chunks/0hn2_h9wwa2.h.css","style"]
:HL["/_next/static/media/47fe1b7cd6e6ed85-s.p.0~mcdl10zdfb3.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/4b766aa38fdaaae3-s.p.0cbnlo4n.czwi.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/829ba4228c966254-s.p.0ub.k0om~_-xi.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/8e6fa89aa22d24ec-s.p.0uvzar8hswo3p.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/a218039a3287bcfd-s.p.17-1enzs_j91b.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/e2334d715941921e-s.p.12skym0rqknxy.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"P":null,"c":["","blog"],"q":"","i":false,"f":[[["",{"children":["blog",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0hn2_h9wwa2.h.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/13x.u8egu.25n.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/08608vuu0xf~j.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"fr","className":"poppins_d8bdde81-module__O_v9ha__variable","children":["$","body",null,{"className":"font-poppins bg-background text-foreground antialiased flex flex-col min-h-screen","children":[["$","$L2",null,{}],["$","main",null,{"className":"flex-grow pt-20","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"flex flex-col items-center justify-center min-h-screen","children":[["$","h2",null,{"className":"text-3xl font-bold","children":"Non trouvé"}],["$","p",null,{"className":"mt-4","children":"Impossible de trouver la ressource demandée"}],["$","$L5",null,{"href":"/","className":"mt-6 text-blue-500 hover:underline","children":"Retour à l'accueil"}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$L6",null,{}],["$","$L7",null,{}]]}]}]]}],{"children":[["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":[["$","$L8",null,{"Component":"$9","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@a","$@b"]}}],[["$","script","script-0",{"src":"/_next/static/chunks/0i-3q5ub1e~p0.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/16swoytb4~dmc.js","async":true,"nonce":"$undefined"}]],["$","$Lc",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@e"}]}]]}],{},null,false,null]},null,false,"$@f"]},null,false,null],["$","$1","h",{"children":[null,["$","$L10",null,{"children":"$L11"}],["$","div",null,{"hidden":true,"children":["$","$L12",null,{"children":["$","$d",null,{"name":"Next.Metadata","children":"$L13"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],false]],"m":"$undefined","G":["$14",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0hn2_h9wwa2.h.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"iSXSXLPEAgYvViEcjDVtR"}
15:[]
f:"$W15"
a:{}
b:"$0:f:0:1:1:children:1:children:0:props:children:0:props:serverProvidedParams:params"
11:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
16:I[13252,["/_next/static/chunks/13x.u8egu.25n.js","/_next/static/chunks/08608vuu0xf~j.js"],"IconMark"]
e:null
13:[["$","title","0",{"children":"PUR Alpha"}],["$","meta","1",{"name":"description","content":"Garde et accompagnement à domicile d'enfants en situation de handicap"}],["$","link","2",{"rel":"icon","href":"/images/logo_pur_alpha.png"}],["$","link","3",{"rel":"apple-touch-icon","href":"/images/logo_pur_alpha.png"}],["$","$L16","4",{}]]
