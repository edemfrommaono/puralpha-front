module.exports=[15015,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_actualite_%5Bslug%5D_page_actions_0_a2b88.js.map