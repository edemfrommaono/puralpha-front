1:"$Sreact.fragment"
2:I[57656,["/_next/static/chunks/0hg7z5z4~4jav.js","/_next/static/chunks/08608vuu0xf~j.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"flex min-h-screen flex-col items-center justify-center p-24","children":[["$","h1",null,{"className":"text-4xl font-bold","children":"Services"}],["$","p",null,{"className":"mt-4 text-xl","children":"Nos services."}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"kP3wuJi_zucsVSbIdCVQf"}
4:null
