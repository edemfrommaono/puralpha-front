module.exports=[45241,a=>{"use strict";a.s(["toHtml",0,function(a){return a?/<[a-z][\s\S]*>/i.test(a)?a:a.split(/\r\n\r\n|\n\n/).map(a=>a.replace(/\r\n|\n/g,"<br />").trim()).filter(Boolean).map(a=>`<p>${a}</p>`).join(""):""}])}];

//# sourceMappingURL=puralpha-front_lib_wysiwyg_ts_09_7k4e._.js.map