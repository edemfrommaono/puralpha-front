module.exports=[23249,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_nos-tarifs_page_actions_0vx7fsy.js.map