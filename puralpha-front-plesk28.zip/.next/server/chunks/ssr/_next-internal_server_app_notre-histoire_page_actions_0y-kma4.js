module.exports=[13695,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_notre-histoire_page_actions_0y-kma4.js.map