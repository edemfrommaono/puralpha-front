module.exports=[17496,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_notre-histoire_page_actions_0lnwi7d.js.map