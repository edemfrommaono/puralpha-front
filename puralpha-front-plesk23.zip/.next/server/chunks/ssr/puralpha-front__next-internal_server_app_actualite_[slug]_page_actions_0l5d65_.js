module.exports=[60906,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_actualite_%5Bslug%5D_page_actions_0l5d65_.js.map