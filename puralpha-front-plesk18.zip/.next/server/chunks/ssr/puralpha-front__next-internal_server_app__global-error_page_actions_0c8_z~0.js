module.exports=[9746,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app__global-error_page_actions_0c8_z~0.js.map