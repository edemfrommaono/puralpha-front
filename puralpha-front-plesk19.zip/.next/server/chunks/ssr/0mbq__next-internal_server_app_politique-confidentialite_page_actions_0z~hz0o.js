module.exports=[68465,(a,b,c)=>{}];

//# sourceMappingURL=0mbq__next-internal_server_app_politique-confidentialite_page_actions_0z~hz0o.js.map