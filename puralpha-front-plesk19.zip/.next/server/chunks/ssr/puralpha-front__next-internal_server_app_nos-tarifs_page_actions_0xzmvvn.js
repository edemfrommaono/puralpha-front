module.exports=[36349,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_nos-tarifs_page_actions_0xzmvvn.js.map