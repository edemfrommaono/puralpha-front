1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/06gyogzomizgk.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/06gyogzomizgk.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/06gyogzomizgk.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"PUR Alpha"}],["$","meta","1",{"name":"description","content":"Garde et accompagnement à domicile d'enfants en situation de handicap"}],["$","link","2",{"rel":"icon","href":"/images/logo_pur_alpha.png"}],["$","link","3",{"rel":"apple-touch-icon","href":"/images/logo_pur_alpha.png"}],["$","$L5","4",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"VAFk6abys3corDNm0Xb4w"}
