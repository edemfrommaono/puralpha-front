module.exports=[40004,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_blog_page_actions_0od28r8.js.map