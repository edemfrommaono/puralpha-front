globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/mhMKZDGpE4ukUH0DpaNYY/_buildManifest.js",
    "static/mhMKZDGpE4ukUH0DpaNYY/_ssgManifest.js",
    "static/mhMKZDGpE4ukUH0DpaNYY/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/15llzq0o8wqiw.js",
    "static/chunks/0ar6p8bkhk97d.js",
    "static/chunks/0--e8y7fci_u9.js",
    "static/chunks/0hxo8q_prabdd.js",
    "static/chunks/turbopack-02hxtpipp-azy.js"
  ]
};
