var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0q7jgck._.js")
R.c("server/chunks/ssr/103u_next_dist_esm_build_templates_app-page_0-5kmo~.js")
R.c("server/chunks/ssr/[root-of-the-server]__02w-zxl._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0nmbsgj._.js")
R.c("server/chunks/ssr/103u_next_dist_client_components_builtin_global-error_0tr3zv7.js")
R.c("server/chunks/ssr/puralpha-front__next-internal_server_app__global-error_page_actions_0c8_z~0.js")
R.m(3816)
module.exports=R.m(3816).exports
