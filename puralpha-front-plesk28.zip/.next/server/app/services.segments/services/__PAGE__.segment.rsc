1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/06gyogzomizgk.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"flex min-h-screen flex-col items-center justify-center p-24","children":[["$","h1",null,{"className":"text-4xl font-bold","children":"Services"}],["$","p",null,{"className":"mt-4 text-xl","children":"Nos services."}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"VAFk6abys3corDNm0Xb4w"}
4:null
