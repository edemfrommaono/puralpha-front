module.exports=[77986,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_contact_page_actions_0z4nuw0.js.map