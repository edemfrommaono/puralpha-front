module.exports=[72665,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_page_actions_0curqrd.js.map