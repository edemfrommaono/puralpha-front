module.exports=[72690,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_actualite_page_actions_09a0dn_.js.map