module.exports=[17465,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_nos-services_page_actions_0xe3mfm.js.map