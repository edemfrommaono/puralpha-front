module.exports=[30644,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_pour-les-familles_page_actions_0jrv2b1.js.map