module.exports=[59290,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_nos-services_page_actions_0r55n2j.js.map