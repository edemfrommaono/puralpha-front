1:"$Sreact.fragment"
2:I[92959,["/_next/static/chunks/0hg7z5z4~4jav.js","/_next/static/chunks/08608vuu0xf~j.js"],"default"]
3:I[28614,["/_next/static/chunks/0hg7z5z4~4jav.js","/_next/static/chunks/08608vuu0xf~j.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"kP3wuJi_zucsVSbIdCVQf"}
