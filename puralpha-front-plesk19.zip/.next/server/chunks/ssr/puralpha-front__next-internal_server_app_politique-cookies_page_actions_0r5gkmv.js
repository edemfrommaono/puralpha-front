module.exports=[82624,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_politique-cookies_page_actions_0r5gkmv.js.map