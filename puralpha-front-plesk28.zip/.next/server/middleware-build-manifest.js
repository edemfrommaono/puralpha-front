globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/VAFk6abys3corDNm0Xb4w/_buildManifest.js",
    "static/VAFk6abys3corDNm0Xb4w/_ssgManifest.js",
    "static/VAFk6abys3corDNm0Xb4w/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0zaia6i55l01..js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0m_p1bxtorv5i.js",
    "static/chunks/02g3221oh~3le.js",
    "static/chunks/turbopack-0~dymj8._h2gc.js"
  ]
};
