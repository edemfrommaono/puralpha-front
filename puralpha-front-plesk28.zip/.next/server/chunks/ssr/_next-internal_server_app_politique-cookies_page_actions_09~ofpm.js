module.exports=[3325,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_politique-cookies_page_actions_09~ofpm.js.map