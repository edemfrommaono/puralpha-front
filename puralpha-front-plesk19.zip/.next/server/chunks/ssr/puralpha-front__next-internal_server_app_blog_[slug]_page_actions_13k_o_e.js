module.exports=[97691,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_blog_%5Bslug%5D_page_actions_13k_o_e.js.map