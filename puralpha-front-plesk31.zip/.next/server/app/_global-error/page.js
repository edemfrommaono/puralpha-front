var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0ypo7ru._.js")
R.c("server/chunks/ssr/node_modules_next_dist_esm_build_templates_app-page_0rc3ul_.js")
R.c("server/chunks/ssr/[root-of-the-server]__0mxeo.-._.js")
R.c("server/chunks/ssr/[root-of-the-server]__00mujn-._.js")
R.c("server/chunks/ssr/node_modules_next_dist_client_components_builtin_global-error_0lgvd_..js")
R.c("server/chunks/ssr/_next-internal_server_app__global-error_page_actions_0k77kol.js")
R.m(42378)
module.exports=R.m(42378).exports
