module.exports=[94085,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_actualite_page_actions_0ipykfw.js.map