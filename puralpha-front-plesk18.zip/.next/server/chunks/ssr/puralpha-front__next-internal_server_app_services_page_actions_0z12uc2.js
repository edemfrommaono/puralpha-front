module.exports=[15766,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_services_page_actions_0z12uc2.js.map