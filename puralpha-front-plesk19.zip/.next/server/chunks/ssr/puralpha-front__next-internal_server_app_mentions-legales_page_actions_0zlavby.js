module.exports=[83919,(a,b,c)=>{}];

//# sourceMappingURL=puralpha-front__next-internal_server_app_mentions-legales_page_actions_0zlavby.js.map